"""Tests for parad CLI."""
